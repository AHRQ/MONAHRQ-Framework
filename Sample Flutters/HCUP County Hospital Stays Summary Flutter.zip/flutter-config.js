
$.monahrq.Flutter.Configs.HCUPFlutter = {
  "id": "gov.ahrq.HCUPFlutter",
  "displayName": "HCUP County Hospital Stay Summary Report",
  "moduleName": "flutters.HCUPFlutter",
  "assets": {
    "scripts": ["basic-table.js", "vendor/angular-smart-table/dist/smart-table.min.js"],
    "styles": ["basic-table.css"],
    "templates": ["views/basic-table.html"]
  },

  "menuItems": [
    {
      "menu": "main",
      "id": "gov.ahrq.HCUPFlutter.Menus.MainTab",
	  "reportId": "gov.ahrq.Reports.HCUP1",
      "label": "HCUP Hospital Stays Summary Report",
	  "priority": 1,
	  "primary": true,
      "classes": [],
	  "route": {
        "name": "top.flutters.HCUPFlutter",
        "params": []
      }
    }
  ],
  "reports": 
  [
    {
      "id": "gov.ahrq.Reports.HCUP1",
      "displayName": "HCUP County Hospital Stays Summary Report",
	  "type": "HCUP County Hospital Stays Summary Report",
      "page": {
        "title": "HCUP County Hospital Stays Summary Report",
        "header": "This report is an example of a summary report.",
        "footer": "To view detail report for County please click on the county name link."
      },
      "custom": {
			"table": {
			  "hasGlobalSearch": true,
			  "hasPager": true,
			  "columns": [
				{"name": "county_name", "label": "County Name", "format": "html"},
				{"name": "total_number_of_discharges", "label": "Total Number of Discharges", "format": "number"},
				{"name": "discharge_rate_100k_population", "label": "Discharge Rate (per 100K population)", "format": "number", "formatOptions": [5]},
				{"name": "mean_los", "label": "Mean Length of Stay", "format": "number", "formatOptions": [2]},
				{"name": "numb_of_days_in_hospital", "label": "Number of Days in Hospital", "format": "number", "formatOptions": [4]},
				{"name": "numb_inpatient_days_100K_population", "label": "Number of Inpatient Days(per 100K population)", "format": "number", "formatOptions": [5]},
				{"name": "mean_cost_stay", "label": "Mean Cost of Stay", "format": "nfcurrency"},
				{"name": "agg_costs_all_hosp_stays", "label": "Aggregate Costs for All Hospital Stays", "format": "nfcurrency"},
				{"name": "costs_inpatient_stays_per_capita", "label": "Costs for Inpatient Stays (per capita)", "format": "nfcurrency"}
			  ]
			},
			"report": {
			  "rootObj": "flutters.hcupcountyhospitalstaysdata.report",
			  "reportName": "summary",
			  "reportDir": "Data/Wings/hcupcountyhospitalstaysdata/",
			  "filePrefix": "summary"
			}
		}
	}
  ]
};
