
$.monahrq.Flutter.Configs.HCUPDetailsFlutter = {
  "id": "gov.ahrq.HCUPDetailsFlutter",
  "displayName": "HCUP County Hospital Stays Details Report",
  "moduleName": "flutters.HCUPDetailsFlutter",
  "assets": {
    "scripts": ["basic-table.js", "vendor/angular-smart-table/dist/smart-table.min.js"],
    "styles": ["basic-table.css"],
    "templates": ["views/basic-table.html"]
  },

  "menuItems": [
    {
      "menu": "main",
      "id": "gov.ahrq.HCUPDetailsFlutter.Menus.MainTab2",
	  "reportId": "gov.ahrq.Reports.HCUP2",
      "label": "HCUP County Hospital Stays Details Report",
	  "priority": 1,
	  "primary": true,
      "classes": [],
	  "route": {
        "name": "top.flutters.HCUPDetailsFlutter",
        "params": []
      }
    }
  ],
  "reports": 
  [
    {
	"id": "gov.ahrq.Reports.HCUP2",
	"displayName": "HCUP County Hospital Stays Detail Report",
	"type": "HCUP County Hospital Stays Detail Report",
	"page": {
	"title": "HCUP County Hospital Stays Details Report",
	"header": "This report is an example of a details report.",
	"footer": "To view hospital profile, please click on the hospital name link."
	},
	"custom": {
	"table": {
		"hasGlobalSearch": true,
		"hasPager": true,
		"columns": [
		{"name": "profile_lnk", "label": "Name", "format": "html"},
		{"name": "total_number_of_discharges", "label": "Total Number of Discharges", "format": "number"},
		{"name": "discharge_rate_100k_population", "label": "Discharge Rate (per 100K population)", "format": "number", "formatOptions": [5]},
		{"name": "mean_los", "label": "Mean Length of Stay", "format": "number", "formatOptions": [2]},
		{"name": "numb_of_days_in_hospital", "label": "Number of Days in Hospital", "format": "number", "formatOptions": [4]},
		{"name": "numb_inpatient_days_100K_population", "label": "Number of Inpatient Days(per 100K population)", "format": "number", "formatOptions": [5]},
		{"name": "mean_cost_stay", "label": "Mean Cost of Stay", "format": "nfcurrency"},
		{"name": "agg_costs_all_hosp_stays", "label": "Aggregate Costs for All Hospital Stays", "format": "nfcurrency"},
		{"name": "costs_inpatient_stays_per_capita", "label": "Costs for Inpatient Stays (per capita)", "format": "nfcurrency"}
		]
	},
	"report": {
		"rootObj": "flutters.hcupcountyhospitalstaysdata.report",
		"reportName": "details",
		"reportDir": "data/wings/hcupcountyhospitalstaysdata/",
		"filePrefix": "details"
    }
    }
	}
  ]
};
