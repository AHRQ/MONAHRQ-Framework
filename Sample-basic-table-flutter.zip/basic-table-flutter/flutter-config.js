
$.monahrq.Flutter.Configs.BasicTableFlutter = {
  id: 'gov.ahrq.BasicTableFlutter',
  displayName: 'Basic Table Flutter',
  moduleName: 'flutters.BasicTableFlutter',
  assets: {
    scripts: ['basic-table.js', 'vendor/angular-smart-table/dist/smart-table.min.js'],
    styles: ['basic-table.css'],
    templates: ['views/basic-table.html']
  },


  menuItems: [
    {
      menu: 'main',
      id: 'gov.ahrq.BasicTableFlutter.Menus.MainTab',
	  reportId: 'gov.ahrq.BasicTableFlutter.Reports.HCUP',
      label: 'HCUP Report',
	  priority: 1,
	  primary: true,
      classes: [],
	  route: {
        name: 'top.flutters.BasicTableFlutter',
        params: []
      }
    },
    {
      menu: 'main',
      id: 'gov.ahrq.BasicTableFlutter.Menus.MainTab2',
      reportId: 'gov.ahrq.BasicTableFlutter.Reports.HCUP2',
      label: 'HCUP Report (2)',
      priority: 2,
      primary: false,
      classes: [],
      route: {
        name: 'top.flutters.BasicTableFlutter',
        params: []
      }
    }
  ],
  reports: [
    {
      id: 'gov.ahrq.BasicTableFlutter.Reports.HCUP',
      displayName: 'HCUP County Hospital Stays',
	  type: 'HCUP County Hospital Stays Data Report',
      page: {
        title: "HCUP County Hospital Stays",
        header: "page header",
        footer: "page footer"
      },
      custom: {
        table: {
          hasGlobalSearch: true,
          hasPager: true,
          columns: [
            {name: 'county_name', label: 'County Name'},
            {name: 'total_number_of_discharges', label: 'Total Number of Discharges', format: 'number'},
            {name: 'mean_los', label: 'Mean Length of Stay', format: 'number', formatOptions: [2]},
            {name: 'mean_cost_stay', label: 'Mean Cost of Stay', format: 'nfcurrency'}
          ]
        },
        report: {
          rootObj: "flutters.hcupcountyhospitalstaysdata.report.summary",
          reportName: 'Summary',
          reportDir: 'Data/Wings/hcupcountyhospitalstaysdata/',
          filePrefix: 'summary'
        }
      }
    },
    {
      id: 'gov.ahrq.BasicTableFlutter.Reports.HCUP2',
      displayName: 'HCUP County Hospital Stays (2)',
	  type: 'HCUP County Hospital Stays Data Report',
      page: {
        title: "HCUP County Hospital Stays (2)",
        header: "page header",
        footer: "page footer"
      },
      custom: {
        table: {
          hasGlobalSearch: false,
          hasPager: false,
          columns: [
            {name: 'county_name', label: 'County Name'},
            {name: 'total_number_of_discharges', label: 'Total Number of Discharges', format: 'number'}
          ]
        },
        report: {
          rootObj: "flutters.hcupcountyhospitalstaysdata.report.summary",
          reportName: 'Summary',
          reportDir: 'Data/Wings/hcupcountyhospitalstaysdata/',
          filePrefix: 'summary'
        }
      }
    }
  ]
};
