/**
 * Monahrq Flutter
 * Basic Table Flutter
 */
(function() {
  'use strict';

  /**
   * Angular wiring
   */
  angular.module('flutters.BasicTableFlutter', ['smart-table'])
    .config(config)
    .controller('BasicTableFlutterCtrl', BasicTableFlutterCtrl);

  var FLUTTER_ID = 'gov.ahrq.BasicTableFlutter';

  /**
   * Angular config
   * Configures the Flutter's state(s) for routing.
   */
  config.$inject = ['$stateProvider'];
  function config($stateProvider) {
    $stateProvider.state('top.flutters.BasicTableFlutter', {
      url: '/basic-table?reportId',
      views: {
        'content@': {
          templateUrl: 'flutters/basic-table-flutter/views/basic-table.html',
          controller: 'BasicTableFlutterCtrl',
          resolve: {
            config: function(FlutterConfigSvc) {
              return FlutterConfigSvc.get(FLUTTER_ID);
            },
            report: function($stateParams, config) {
              return _.findWhere(config.reports, {id: $stateParams.reportId});
            },
            wing: function(report, SimpleReportLoaderSvc) {
              return SimpleReportLoaderSvc.load(report.custom.report);
            }
          }
        }
      }
    });
  }

  /**
   * BasicTableFlutterCtrl
   * Builds data model and respond to user interactions.
   */
  BasicTableFlutterCtrl.$inject = ['$scope', '$filter', 'config', 'report', 'wing'];
  function BasicTableFlutterCtrl($scope, $filter, config, report, wing) {
    $scope.getValue = getValue;
    $scope.page = report.page;
    $scope.table = report.custom.table;

    init();


    function init() {
      updateTable();
    }

    function updateTable() {
      $scope.model = wing.data;
      $scope.displayModel = [];

      _.each($scope.model, function(row) {
        formatRow(row);
        $scope.displayModel.push(row);
      });

    }

    function formatRow(row) {
      _.each(report.custom.table.columns, function(col) {
        if (_.has(col, 'format')) {
          row['f' + col.name] = formatField(col, row[col.name]);
        }
      });
    }

    function formatField(col, value) {
      var options = [];
      if (_.has(col, 'formatOptions')) {
        options = col.formatOptions;
      }

      var params = [value].concat(options);
      return $filter(col.format).apply(undefined, params);
    }

    function getValue(field, row) {
      if (_.has(row, 'f' + field)) {
        return row['f' + field];
      }

      return row[field];
    }


  }

})();


